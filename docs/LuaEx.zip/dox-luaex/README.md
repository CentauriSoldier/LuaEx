# dox-luaex

Generated from Dox comments.

Install: unpack this archive into your Pulsar packages directory, preserving the package folder, then reload Pulsar. Enable autocomplete-lua or autocomplete-luaex; this package supplies their documented options-provider service.

Includes documented names, descriptions, arguments, returns and fields. Types not documented remain unknown; no source code is executed to infer them.
